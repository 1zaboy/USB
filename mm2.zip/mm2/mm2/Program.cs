﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mm2
{  
    class Program
    {
        static public double[,] mas;
        static public double[,] mas1;
        static public int mas_size;
        static public string answer;
        static public double[,] max_znach(double[,] maz)
        {
            for (int i = 0; i < mas_size; i++)
            {
                for (int j = 0; j < mas_size; j++)
                {
                    if(maz[i,j]==0)
                    {
                        maz[i, j] = double.MaxValue;
                    }
                }
            }
            for (int j = 0; j < mas_size; j++)
            {
                maz[j, j] = 0;
            }
            return maz;
        }
        static public void Enter()
        {
            for (int i = 0; i < mas_size; i++)
            {
                for (int j = 0; j < mas_size; j++)
                {
                    Console.Write(" Строка: " + i + "   Столбец: " + j + ": ");
                    mas[i, j] = Convert.ToDouble(Console.ReadLine());
                }
            }
            mas = max_znach(mas);
        }
        static public void Enter0()
        {
            mas = new double[,] { { 0,5,3,0,0,0,0,0,0,0},
                    { 5,0,0,0,0,0,1,0,0,0},
                    { 3,0,0,4,0,7,0,0,0,0},
                    { 0,0,4,0,10,8,0,0,9,0},
                    { 0,0,0,10,0,0,2,1,0,0},
                    { 0,0,0,8,0,0,0,0,2,0},
                    { 0,1,0,0,2,0,0,0,0,0},
                    { 0,0,0,0,1,0,0,0,6,0},
                    { 0,0,0,9,0,2,0,6,0,4},
                    { 0,0,0,0,0,0,0,0,4,0}};
            mas = max_znach(mas);
        }
        static public void Enter1()
        {
            for (int i = 0; i < mas_size; i++)
            {
                for (int j = 0; j < mas_size; j++)
                {                    
                    mas1[i, j] = j+1;
                }
            }
            mas1 = max_znach(mas1);
        }
        static public void Draw(double[,] maz)
        {
            for (int i = 0; i < mas_size; i++)
            {
                for (int j = 0; j < mas_size; j++)
                {
                    if (maz[i, j] == double.MaxValue)
                    {
                        Console.Write("^" + "\t");
                    }
                    else
                    {
                        Console.Write(maz[i, j] + "\t");
                    }
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
        static public void Draw_Path()
        {
            //double sz, p = 0;
            int _from = Convert.ToInt32(Console.ReadLine())-1;
            int _in = Convert.ToInt32(Console.ReadLine())-1;           
            int _f = _from;
            int _i = _in;            
            answer += _from+1 + "-";
            do
            {
                if(mas1[_f, _i]==mas1[_f, (int)mas1[_f, _i]-1])
                {
                    answer += mas1[_f, _i] + "-";
                    _f = (int)mas1[_f, _i]-1;
                    _i = _in;
                }
                else
                {
                    _i = (int)mas1[_f, (int)mas1[_f, _i]-1]-1;
                }
               
            } while (mas1[_f, _i] != _in+1);
            answer += _in+1;            
            Console.WriteLine(answer);
            answer = answer.Remove(0);
        }
        static void Main(string[] args)
        {
            mas_size = Convert.ToInt32(Console.ReadLine());
            mas = new double[mas_size, mas_size];
            mas1 = new double[mas_size, mas_size];
            //Enter();
            Enter0();
            Enter1();
            Draw(mas);
            
            for (int t = 0; t < mas_size; t++)
            {
                for (int i = 0; i < mas_size; i++)
                {
                    for (int j = 0; j < mas_size; j++)
                    {
                        if (mas[i, t] + mas[t, j] < mas[i, j])
                        {
                            mas[i, j] = mas[i, t] + mas[t, j];
                            mas1[i, j] = t + 1;
                        }                        
                    }
                }
                Console.WriteLine(t);
                Draw(mas1);
                Draw(mas);
                Console.WriteLine();
            }
            Draw(mas1);
            Draw(mas);
            while (true)
            {
                Draw_Path();
            }            
        }
    }
}
