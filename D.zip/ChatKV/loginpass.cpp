#include "loginpass.h"
#include "ui_loginpass.h"
#include <QFile>
#include <QObject>
#include <QProcess>
LoginPass::LoginPass(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginPass)
{
    ui->setupUi(this);
}

LoginPass::~LoginPass()
{
    delete ui;
}

void LoginPass::on_buttonBox_accepted()
{
    login=ui->lineEdit_Login->text();
    pass=ui->lineEdit_Pass->text();
    this->close();
}

void LoginPass::on_pushButton_clicked()
{
    QString appPath = QCoreApplication::applicationDirPath() + "/spravkackv.chm";
    QStringList param;
    param.append(appPath);
    QProcess v;
    v.execute("hh.exe", param);
}
