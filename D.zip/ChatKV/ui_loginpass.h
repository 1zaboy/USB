/********************************************************************************
** Form generated from reading UI file 'loginpass.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINPASS_H
#define UI_LOGINPASS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_LoginPass
{
public:
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_Login;
    QLineEdit *lineEdit_Pass;
    QDialogButtonBox *buttonBox;
    QPushButton *pushButton;

    void setupUi(QDialog *LoginPass)
    {
        if (LoginPass->objectName().isEmpty())
            LoginPass->setObjectName(QStringLiteral("LoginPass"));
        LoginPass->resize(175, 150);
        gridLayout = new QGridLayout(LoginPass);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        lineEdit_Login = new QLineEdit(LoginPass);
        lineEdit_Login->setObjectName(QStringLiteral("lineEdit_Login"));
        lineEdit_Login->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lineEdit_Login->sizePolicy().hasHeightForWidth());
        lineEdit_Login->setSizePolicy(sizePolicy);
        lineEdit_Login->setAutoFillBackground(false);

        gridLayout->addWidget(lineEdit_Login, 1, 0, 1, 1);

        lineEdit_Pass = new QLineEdit(LoginPass);
        lineEdit_Pass->setObjectName(QStringLiteral("lineEdit_Pass"));
        sizePolicy.setHeightForWidth(lineEdit_Pass->sizePolicy().hasHeightForWidth());
        lineEdit_Pass->setSizePolicy(sizePolicy);

        gridLayout->addWidget(lineEdit_Pass, 2, 0, 1, 1);

        buttonBox = new QDialogButtonBox(LoginPass);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 3, 0, 1, 1);

        pushButton = new QPushButton(LoginPass);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setEnabled(true);

        gridLayout->addWidget(pushButton, 0, 0, 1, 1);


        retranslateUi(LoginPass);
        QObject::connect(buttonBox, SIGNAL(accepted()), LoginPass, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), LoginPass, SLOT(reject()));

        QMetaObject::connectSlotsByName(LoginPass);
    } // setupUi

    void retranslateUi(QDialog *LoginPass)
    {
        LoginPass->setWindowTitle(QApplication::translate("LoginPass", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("LoginPass", "?", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class LoginPass: public Ui_LoginPass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINPASS_H
