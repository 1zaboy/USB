#ifndef LOGINPASS_H
#define LOGINPASS_H

#include <QDialog>

namespace Ui {
class LoginPass;
}

class LoginPass : public QDialog
{
    Q_OBJECT

public:
    QString login;
    QString pass;
    explicit LoginPass(QWidget *parent = 0);
    ~LoginPass();

private slots:
    void on_buttonBox_accepted();

    void on_pushButton_clicked();

private:
    Ui::LoginPass *ui;
};

#endif // LOGINPASS_H
