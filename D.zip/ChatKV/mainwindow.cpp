#include <QObject>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "loginpass.h"
#include <QtNetwork>
#include <QFile>
#include <QInputDialog>
#include <Qt>
#include <QLabel>
#include <QPainter>
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_pTcpSocket = new QTcpSocket(this);
    m_nNextBlockSize=0;
    bool ok;
        QString serverIp = QInputDialog::getText(this, tr("Введите адрес сервера"),tr("Адрес сервера:"), QLineEdit::Normal,"localhost", &ok);
        if (ok && !serverIp.isEmpty())
        {

    m_pTcpSocket->connectToHost(serverIp, 2323);
        }
        else
        {
    m_pTcpSocket->connectToHost("localhost", 2323);
        }
    connect(m_pTcpSocket, SIGNAL(connected()), SLOT(slotConnected()));
    connect(m_pTcpSocket, SIGNAL(readyRead()), SLOT(slotReadyRead()));
    connect(m_pTcpSocket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(slotError(QAbstractSocket::SocketError)));
}
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    LoginPass mydialog;
    mydialog.exec();
    QString login= mydialog.login;
    QString pass=mydialog.pass;
    QString loginpass=login+'\t'+pass;
    QChar A;
    A='l';

    SendToServerLine(A,loginpass);

}
void MainWindow::slotReadyRead()
{
    QDataStream in(m_pTcpSocket);
    in.setVersion(QDataStream::Qt_5_9);
    for (;;)
    {
        if (!m_nNextBlockSize)
        {
            if (m_pTcpSocket->bytesAvailable() < (int)sizeof(quint16))
            {
                break;
            }
            in >> m_nNextBlockSize;
        }
        if (m_pTcpSocket->bytesAvailable() < m_nNextBlockSize)
        {
            break;
        }
        QTime   time;
        QString str=ui->lineEdit->text();

        in >> time >> str;

        ui->textEdit->append(time.toString() + " " + str);
        ui->textEdit->textChanged();
        m_nNextBlockSize = 0;
    }
}

void MainWindow::SendToServerLine(QChar A, QString chatline)
{
    QByteArray  arrBlock;
    QDataStream out(&arrBlock, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_9);

    out << quint16(0)<< A << QTime::currentTime() <<chatline;

    out.device()->seek(0);
    out << quint16(arrBlock.size() - sizeof(quint16));

    m_pTcpSocket->write(arrBlock);

}
void MainWindow::on_pushButton_2_clicked()
{
    QString chatline= ui->lineEdit->text();
    QChar A;
    A='1';
    if(chatline!="")
    {
    //QString B =ui->textEdit->toPlainText();
   // ui->textEdit->setText(B+chatline + '\n');
   ui->lineEdit->clear();
   SendToServerLine(A,chatline);
    }
}

void MainWindow::on_pushButton_3_clicked()
{
    QString appPath = QCoreApplication::applicationDirPath() + "/spravkackv.chm";
    QStringList param;
    param.append(appPath);
    QProcess v;
    v.execute("hh.exe", param);
}
