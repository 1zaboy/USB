#ifndef ChatUser_H
#define ChatUser_H
#include <QObject>

class ChatUser
{
public:
    ChatUser();
    QString pass;
    QString name;
    int userID;
    int socketDescriptor;
private:

};

#endif // ChatUser_H
