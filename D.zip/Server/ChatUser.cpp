#include "ChatUser.h"

ChatUser::ChatUser()
{

}
