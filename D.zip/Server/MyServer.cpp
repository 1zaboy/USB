#include <QtNetwork>
#include <QtWidgets>
#include "MyServer.h"
#include "ChatUser.h"
#include <QtCore>
#include <QFile>
// ----------------------------------------------------------------------
MyServer::MyServer(int nPort, QWidget* pwgt /*=0*/) : QWidget(pwgt), m_nNextBlockSize(0)
{
    m_ptcpServer = new QTcpServer(this);

    if (!m_ptcpServer->listen(QHostAddress::Any, nPort))
    {
        QMessageBox::critical(0, "Server Error", "Unable to start the server:" + m_ptcpServer->errorString());
        m_ptcpServer->close();
        return;
    }
    connect(m_ptcpServer, SIGNAL(newConnection()), this, SLOT(slotNewConnection()));
    m_ptxt = new QTextEdit;
    m_ptxt->setReadOnly(true);
    QString ip_adr="";
    foreach (const QHostAddress &address, QNetworkInterface::allAddresses())
    {
        if (address.protocol() == QAbstractSocket::IPv4Protocol && address != QHostAddress(QHostAddress::LocalHost))
        {
            ip_adr.append(address.toString());
            ip_adr.append("<br>");
        }
    }

    //Layout setup
    QVBoxLayout* pvbxLayout = new QVBoxLayout;
    pvbxLayout->addWidget(new QLabel("<H1>Server IP:</H1>" + ip_adr));
    pvbxLayout->addWidget(m_ptxt);
    setLayout(pvbxLayout);
    LoadUsersDB();
}
void MyServer::LoadUsersDB()
{
    QFile z("user.txt");
    if (z.exists())
    {
        if (z.open(QIODevice::ReadOnly))
        {
            QTextStream stream(&z);
            QString str= stream.readAll();
            z.close();
            m_ptxt->append("прочитали базу пользователей");
            ChatUsers.clear();
            QStringList users=str.split('\n');
            for (int i = 0; i < users.size()-1; ++i)
            {
                QString us=users[i];
                QStringList us_lp=us.split('\t');
                ChatUser newuser;
                newuser.name=us_lp[0];
                newuser.pass=us_lp[1];
                ChatUsers.insert(newuser.name,newuser);
            }
        }
    }
    else
    {
        m_ptxt->append("нет базы пользователей");
    }
}

void MyServer::SaveUsersDB(QString name)
{
    QFile z("user.txt");

    if (z.open(QIODevice::Append))
    {
        m_ptxt->append("сохраним нового пользователя");
        QTextStream stream(&z);
        stream<<ChatUsers[name].name << '\t' << ChatUsers[name].pass<<'\n';
        z.close();
    }

}

// ----------------------------------------------------------------------
/*virtual*/ void MyServer::slotNewConnection()
{
    QTcpSocket* pClientSocket = m_ptcpServer->nextPendingConnection();
    //connect(pClientSocket, SIGNAL(disconnected()), pClientSocket, SLOT(deleteLater()));
    connect(pClientSocket, SIGNAL(readyRead()), this, SLOT(slotReadClient()));
    connect(pClientSocket, SIGNAL(disconnected()), this, SLOT(slotCloseClient()));
    m_ptxt->append("NewConn");
    QString msg="Connected!";
    int idSoc=pClientSocket->socketDescriptor();
    SClients[idSoc]=pClientSocket;
    sendToClient(pClientSocket, msg);
}


// ----------------------------------------------------------------------
void MyServer::slotCloseClient()
{
    QTcpSocket* pClientSocket = (QTcpSocket*)sender();
    QAbstractSocket* pAS=(QAbstractSocket*)pClientSocket;

    foreach(int Socet,SClients.keys())
    {
        if (pAS==(QAbstractSocket*)SClients[Socet])
        {
            m_ptxt->append("Откл. пользователь: " + SocetIDtoUser[Socet]);
            SocetIDtoUser.remove(Socet);
            SClients.remove(Socet);
            pClientSocket->deleteLater();
            return;
        }
    }

}

void MyServer::slotReadClient()
{
    QTcpSocket* pClientSocket = (QTcpSocket*)sender();
    QDataStream in(pClientSocket);
    in.setVersion(QDataStream::Qt_5_9);

    for (;;)
    {
        if (!m_nNextBlockSize)
        {
            if (pClientSocket->bytesAvailable() < (int)sizeof(quint16))
            {
                break;
            }
            in >> m_nNextBlockSize;
        }

        if (pClientSocket->bytesAvailable() < m_nNextBlockSize)
        {
            break;
        }

        QTime   time;
        QString str;
        QChar marker;

        in >> marker >> time >> str;

        int idSoc=pClientSocket->socketDescriptor();

        if (marker=='1')
        {
            if (SocetIDtoUser.contains(idSoc))
            {
                QString Login=SocetIDtoUser[idSoc];
                QString NewMsg="<b>" + Login + ": </b>" + str;
                msg.append(NewMsg);
                QString strMessage =time.toString() + " " + "Client has sent txt - " + str;
                m_ptxt->append(strMessage);
                foreach(int SocetID,SocetIDtoUser.keys())
                {
                    if (SClients[SocetID]->isValid())
                    {
                        sendToClient(SClients[SocetID], NewMsg);
                    }
                }
            }
        }
        if (marker=='l')
        {
            QString strMessage1 = time.toString() + " " + "Client has sent - " + str;
            m_ptxt->append(strMessage1);
            QStringList logpass=str.split('\t');
            QString Login=logpass[0];
            QString Pass=logpass[1];
            if(ChatUsers.contains(Login))
            {
                if(ChatUsers[Login].pass==Pass)
                {
                    m_ptxt->append("Зашёл пользователь: "+Login);
                    int idSoc=pClientSocket->socketDescriptor();
                    ChatUsers[Login].socketDescriptor;
                    SocetIDtoUser[idSoc]=Login;

                }
                else
                {
                    m_ptxt->append("Неверный пароль пользователя: "+logpass[0]);
                }
            }
            else
            {
                ChatUser newuser;
                newuser.name=logpass[0];
                newuser.pass=logpass[1];
                ChatUsers.insert(newuser.name,newuser);
                m_ptxt->append("Создан новый пользователь: "+newuser.name);
                SaveUsersDB(newuser.name);

                int idSoc=pClientSocket->socketDescriptor();
                ChatUsers[Login].socketDescriptor;
                SocetIDtoUser[idSoc]=Login;

            }
        }

        m_nNextBlockSize = 0;


    }
}

// ----------------------------------------------------------------------
void MyServer::sendToClient(QTcpSocket* pSocket, const QString& str)
{
    QByteArray  arrBlock;
    QDataStream out(&arrBlock, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_9);
    if (str!=NULL)
    {
        out << quint16(0) << QTime::currentTime() << str;
    }
    out.device()->seek(0);
    out << quint16(arrBlock.size() - sizeof(quint16));
    pSocket->write(arrBlock);
}


