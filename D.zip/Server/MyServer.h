// ======================================================================
//  MyServer.h
// ======================================================================
//                   This file is a part of the book 
//             "Qt 5.3 Professional programming with C++"
// ======================================================================
//  Copyright (c) 2014 by Max Schlee
//
//  Email : Max.Schlee@neonway.com
//  Blog  : http://www.maxschlee.com
//
//  Social Networks
//  ---------------
//  FaceBook : http://www.facebook.com/mschlee
//  Twitter  : http://twitter.com/Max_Schlee
//  2Look.me : http://2look.me/NW100003
//  Xing     : http://www.xing.com/profile/Max_Schlee
//  vk.com   : https://vk.com/max.schlee
// ======================================================================

#pragma once

#include <QWidget>
#include "ChatUser.h"
#include <QtCore>
class QTcpServer;
class QTextEdit;
class QTcpSocket;

// ======================================================================
class MyServer : public QWidget {
Q_OBJECT
private:
    QTcpServer* m_ptcpServer;
    QTextEdit*  m_ptxt;
    quint16     m_nNextBlockSize;    
    QMap<QString, ChatUser> ChatUsers; //Наши пользователи
    QMap<int,QTcpSocket *> SClients; // Тут все подключения клиентов
    QMap<int,QString> SocetIDtoUser; //Соответствие сокета и юзера
    QList<QString> msg; //Сообщения


private:
    void sendToClient(QTcpSocket* pSocket, const QString& str);
    void praverkaLoginPass(QString str);
    void LoadUsersDB();
    void SaveUsersDB(QString name);
public:
    MyServer(int nPort, QWidget* pwgt = 0);


public slots:
     void slotNewConnection();
     void slotReadClient();
     void slotCloseClient();
};

