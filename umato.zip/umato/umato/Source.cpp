#include <iostream>
#include "Header.h"
using namespace std;
void main()
{
	setlocale(0, "");
	Triangle t;
	cout << "vedite treugolnik" << endl;
	t.InputTriangle();

	if(t.TestOnTriangle())
	{
		t.CalculatingPoints();
		cout << "this is Triangle" << endl;
		if(t.TestOnIsoscelesTriangle())
			cout << "this is Isosceles Triangle" << endl;
		if (t.TestOnEquilateralTriangle())
			cout << "this is Equilateral Triangle" << endl;
	}
	system("pause");
}
